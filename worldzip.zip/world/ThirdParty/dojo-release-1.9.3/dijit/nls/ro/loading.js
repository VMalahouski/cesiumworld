//>>built
define("dijit/nls/ro/loading",({loadingState:"Încărcare...",errorState:"Ne pare rău, a apărut o eroare "}));
