//>>built
define("dijit/nls/th/common",({buttonOk:"ตกลง",buttonCancel:"ยกเลิก",buttonSave:"บันทึก",itemClose:"ปิด"}));
